const express = require("express");
const app = express();
app.use(express.json());

app.post("/api/generate", (req, res) => {
  const idea = req.body.inputText || "default";
  // Simulate Haiku (in real app, use AI like OpenAI)
  const haiku = `Generated Haiku for ${idea}: Line 1.\nLine 2.\nLine 3.`;
  res.json({
    fcFrame: "vNext",
    fcFrameImage: "https://your-image-url.com/generated.png",
    fcFramePostUrl: "https://your-vercel-url.com/api/generate", // Self or next step
    fcFrameButtons: [{ label: "Share Haiku", action: "post" }],
  });
});

app.listen(3000, () => console.log("Server running"));
